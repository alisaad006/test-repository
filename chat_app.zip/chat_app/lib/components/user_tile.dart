import 'package:flutter/material.dart';

class UserTile extends StatelessWidget {
  final String text;
  final void Function()? onTap;
  final TextStyle? textStyle; // إضافة textStyle كخاصية اختيارية

  const UserTile({
    super.key,
    required this.text,
    required this.onTap,
    this.textStyle, // استلام textStyle في البناء
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        decoration: BoxDecoration(
          color: Theme.of(context).colorScheme.secondary,
          borderRadius: BorderRadius.circular(12),
        ),
        child: Row(
          children: [
            const Icon(Icons.person),
            const SizedBox(width: 8), // مسافة بين الأيقونة والنص
            Text(
              text,
              style: textStyle ?? const TextStyle(), // استخدام textStyle إذا كان متاحًا
            ),
          ],
        ),
      ),
    );
  }
}